package com.example.fuadmaska.myfeature;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.fuadmaska.myfeature.R;

public class ClaimTrackIdNotFoundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claim_track_id_not_found);
    }
}
