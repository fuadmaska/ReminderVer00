package com.example.fuadmaska.myfeature.Interfaces;

public interface callBack {
    void OnCallBack(String title);
}
