package com.example.fuadmaska.myfeature.Model;

public class HomeNewsDataModel {

    private String Title;


    public HomeNewsDataModel(String Title){
        this.Title = Title;

    }



    public void setTitle(String title) {
        Title = title;
    }



    public String getTitle() {
        return Title;
    }
}
